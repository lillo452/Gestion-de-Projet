public interface Position {
    Position makeCopy();
}
