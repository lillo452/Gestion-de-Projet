Projet SudoCul :


Projet de réalisation d'un solveur CSP de sudoku en Java. Ce projet a été réalisé dans le cadre de notre cursus universitaire, plus précisément dans l'UE Gestion de Projet de notre troisième année de licence en informatique.

Le projet à était réalisé en équipe :
	
	- Lillo GAVOIS
	- Frank LEGGETT
	- Wail AMEUR
	- Charles THIEBAUT
	- Antony FERRY

Pour mener à thermes notre projet nous avons utilisé plusieurs logiciel :

	- Visual Studio Code
	- Netbeans IDE
	- GitHub
	- Teams & la suite Microsoft 365 (Office)
	
Pour lancer l'interface de résolution Sudoku depuis répértoire racine : java -classpath distrib/sudoku.jar:distrib/solveurCSP.jar:distrib/interfacecsp.jar: interfacecsp.InterfaceApplication
