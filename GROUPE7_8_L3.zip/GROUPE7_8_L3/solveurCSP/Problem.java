package solveurCSP;

/**
 * This interface represents a generic problem.
 * @param <type> the type of the variable
 * @author Charles THIEBAUT
 * @version 1.0
 */
public interface Problem<type> {
    Position getPos();
    Domain<type> getDomain();
    void setPos(Position pos);
    void addValue(type value, int x, int y);

    boolean wasInitiallyFilled(int row, int col);
    void setValue(type value);
    void nextPos();
    Problem<type> makeCopy();
    boolean isBeggining();
    boolean isEnd();
    boolean isSolved();
    void print();
    boolean isFilled(int row, int col);
    boolean isValidGrid();
}
